{{/*
Expand the name of the chart.
*/}}
{{- define "persistence-layer.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "persistence-layer.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart-level resource labels to be applied to every resource.
*/}}
{{- define "persistence-layer.labels" -}}
helm.sh/chart: {{ include "persistence-layer.name" . }}
{{ include "persistence-layer.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels used by Deployments, StatefulSets, etc.
*/}}
{{- define "persistence-layer.selectorLabels" -}}
app.kubernetes.io/name: {{ include "persistence-layer.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
PostgreSQL secret name
*/}}
{{- define "postgresql.secretName" -}}
{{ .Release.Name }}-postgresql
{{- end }}

{{/*
SeaweedFS secret name
*/}}
{{- define "seaweedfs.secretName" -}}
{{ .Release.Name }}-seaweedfs
{{- end }}

{{/*
PostgreSQL service host
*/}}
{{- define "postgresql.host" -}}
{{ .Release.Name }}-postgresql
{{- end }}

{{/*
PostgreSQL service port
*/}}
{{- define "postgresql.port" -}}
{{ .Values.postgresql.service.ports.postgresql }}
{{- end }}

{{/*
SeaweedFS S3 URL
*/}}
{{- define "seaweedfs.s3url" -}}
http://{{ .Release.Name }}-seaweedfs:{{ .Values.seaweedfs.service.ports.s3 }}
{{- end }}
