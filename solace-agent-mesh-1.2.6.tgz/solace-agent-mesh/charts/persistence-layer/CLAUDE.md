# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

This is a Helm chart that provides a reusable single-instance persistence layer for Kubernetes applications. The chart deploys PostgreSQL and SeaweedFS (S3-compatible storage) as subcharts and is designed to be used as either:

1. **A subchart** in applications that need to deploy their own persistence layer
2. **A connection target** for applications that need to connect to an existing persistence layer

## Architecture

The project uses a two-chart approach:

- **Charts with persistence**: Include this chart as a subchart and deploy PostgreSQL/SeaweedFS instances
- **Charts connecting to persistence**: Use `namespaceId` to discover connection secrets from existing deployments

Key architectural components:
- `/charts/postgresql/` - PostgreSQL subchart with StatefulSet, Service, and Secret templates
- `/charts/seaweedfs/` - SeaweedFS subchart with StatefulSet, Service, Secret, and ConfigMap templates
- `/templates/_helpers.tpl` - Main chart helpers for credential access and service discovery
- `/examples/` - Working examples of both chart usage patterns

## Common Commands

### Helm Operations
```bash
# Install the chart as a subchart dependency
helm dependency build

# Test templates (requires cluster access for lookup functions)
helm install my-release . --dry-run=server

# Package the chart
helm package .

# Lint the chart
helm lint .
```

### Development and Testing
```bash
# Test the chart-with-persistence example
cd examples/chart-with-persistence
helm dependency build
helm install test-with-persistence . --dry-run=server

# Test the chart-connecting-to-persistence example  
cd examples/chart-connecting-to-persistence
helm install test-connecting . --dry-run=server
```

## Key Configuration

### Required Global Values
- `global.persistence.namespaceId`: Unique identifier for service discovery across charts

### Service Configuration
- `postgresql.username/password`: Database credentials (cannot be changed after installation)
- `seaweedfs.persistence.size`: Storage size for SeaweedFS (PostgreSQL has root credentials, SeaweedFS does not seed credentials)

Note: SeaweedFS does not provide seeded credentials. Applications are responsible for provisioning S3 users, buckets, and access policies during their initialization using weed shell commands.

## Template Helper Functions

The chart provides helpers for accessing credentials and connection details:

**For subcharts:**
- `postgresql.secretName` - Get PostgreSQL root credentials secret name
- `seaweedfs.secretName` - Get SeaweedFS connection details secret name (endpoints only, no credentials)
- `postgresql.host/port` - Get PostgreSQL connection details
- `seaweedfs.s3url` - Get SeaweedFS S3 endpoint URL

**For connecting charts:**
Charts must implement their own discovery helpers using the `lookup` function to find secrets by `namespaceId` and service labels.

## Important Notes

- Use `helm install --dry-run=server` for testing (not `helm template`) because lookup functions require cluster API access
- PostgreSQL root credentials are for provisioning only - applications should create and use less-privileged credentials
- SeaweedFS does not provide root credentials - applications provision S3 users and buckets using weed shell during initialization
- The `namespaceId` must be unique within the namespace for proper service discovery
- Secrets are labeled with `app.kubernetes.io/namespace-id` and `app.kubernetes.io/service` for discovery

## Versioning & Release Process

This project uses **conventional commits** for automatic semantic versioning. The **PR title** (not individual commit messages) determines the version bump:

- `feat:` or `feat(component):` → Minor version bump (1.2.0 → 1.3.0)
- `fix:` or `fix(component):` → Patch version bump (1.2.0 → 1.2.1)
- `chore:` → No version bump

**Example PR titles:**
```
feat: add component-specific Datadog service tags
fix: quote image tags to preserve version format
chore: update documentation
```

### Version Format Consistency
**Critical:** Always quote version numbers in Chart.yaml to preserve format:

```yaml
# Chart.yaml - CORRECT
appVersion: "18.0"

# Chart.yaml - WRONG (becomes "18")
appVersion: 18.0
```

Without quotes, YAML parsers truncate (18.0 → 18), causing inconsistency between `app.kubernetes.io/version` and `tags.datadoghq.com/version` labels.

## Datadog Observability

### Unified Service Tagging
Each component has component-specific `service` and `version` tags for proper Datadog grouping:

**PostgreSQL:**
```yaml
tags.datadoghq.com/service: "postgresql"
tags.datadoghq.com/version: "18.0"  # from image.tag
```

**SeaweedFS:**
```yaml
tags.datadoghq.com/service: "seaweedfs"
tags.datadoghq.com/version: "3.97"  # from image.tag
```

### Custom Autodiscovery Tags
Both subcharts support custom tags via `datadog.tags`:

```yaml
postgresql:
  datadog:
    tags:
      env: production
      team: platform
```

Rendered as pod annotation: `ad.datadoghq.com/tags: '{"env":"production","team":"platform"}'`

### Implementation Pattern
Each subchart has Datadog helpers in `templates/_helpers.tpl`:

```yaml
{{- define "postgresql.datadogServiceLabels" -}}
tags.datadoghq.com/service: "postgresql"
{{- if .Values.image.tag }}
tags.datadoghq.com/version: {{ .Values.image.tag | quote }}
{{- end }}
{{- end }}

{{- define "postgresql.resourceLabels" -}}
{{- include "postgresql.labels" . }}
{{- if .Values.podLabels }}
{{ .Values.podLabels | toYaml }}
{{- end }}
{{ include "postgresql.datadogServiceLabels" . }}
{{- end }}
```

Apply `resourceLabels` to all K8s resources including StatefulSets, Services, and volumeClaimTemplates for consistent tagging.