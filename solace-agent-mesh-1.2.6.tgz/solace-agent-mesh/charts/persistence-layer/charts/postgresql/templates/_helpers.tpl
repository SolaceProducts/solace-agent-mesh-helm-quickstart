{{/*
Expand the name of the chart.
*/}}
{{- define "postgresql.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "postgresql.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "postgresql.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "postgresql.labels" -}}
helm.sh/chart: {{ include "postgresql.chart" . }}
{{ include "postgresql.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "postgresql.selectorLabels" -}}
app.kubernetes.io/name: {{ include "postgresql.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Datadog autodiscovery annotations for pod-level tags
*/}}
{{- define "postgresql.datadogAnnotations" -}}
{{- if .Values.datadog.tags }}
ad.datadoghq.com/tags: '{{ .Values.datadog.tags | toJson }}'
{{- end }}
{{- end }}

{{/*
Unified service tagging labels for Datadog
*/}}
{{- define "postgresql.datadogServiceLabels" -}}
tags.datadoghq.com/service: "postgresql"
{{- if .Values.image.tag }}
tags.datadoghq.com/version: {{ .Values.image.tag | quote }}
{{- end }}
{{- end }}

{{/*
Resource labels including podLabels for consistent tagging across all resources
*/}}
{{- define "postgresql.resourceLabels" -}}
{{- include "postgresql.labels" . }}
{{- if .Values.podLabels }}
{{ .Values.podLabels | toYaml }}
{{- end }}
{{ include "postgresql.datadogServiceLabels" . }}
{{- end }}

{{/*
Volume claim template labels - backwards compatible.
If explicit volumeClaimLabels provided via values, use them exactly (for upgrades).
Otherwise use minimal selector labels (for new installs).
VolumeClaimTemplate labels are immutable once a StatefulSet is created. Only include stable
labels that won't change during upgrades. Excludes by default:
- podLabels (deployment-id, org-id, etc. may be added over time)
- helm.sh/chart (changes if chart version bumps)
- app.kubernetes.io/version (changes if appVersion bumps)
- tags.datadoghq.com/* (version changes if image tag changes)
*/}}
{{- define "postgresql.volumeClaimLabels" -}}
{{- if .Values.volumeClaimLabels }}
{{- .Values.volumeClaimLabels | toYaml }}
{{- else }}
{{ include "postgresql.selectorLabels" . }}
{{- end }}
{{- end }}
