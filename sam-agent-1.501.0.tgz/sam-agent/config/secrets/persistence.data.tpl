{{- if .Values.persistence.createSecrets -}}
{{- $storageType := include "sam.objectStorage.type" . -}}
DATABASE_URL: {{ include "sam.postgresql.databaseUrl" . | b64enc }}
OBJECT_STORAGE_TYPE: {{ $storageType | b64enc }}
{{- if eq $storageType "azure" }}
AZURE_STORAGE_ACCOUNT_NAME: {{ include "sam.azure.accountName" . | b64enc }}
{{- if not .Values.persistence.objectStorage.workloadIdentity.enabled }}
AZURE_STORAGE_ACCOUNT_KEY: {{ include "sam.azure.accountKey" . | b64enc }}
AZURE_STORAGE_CONNECTION_STRING: {{ include "sam.azure.connectionString" . | b64enc }}
{{- end }}
AZURE_STORAGE_CONTAINER_NAME: {{ include "sam.azure.containerName" . | b64enc }}
{{- else if eq $storageType "gcs" }}
GCS_PROJECT: {{ include "sam.gcs.project" . | b64enc }}
{{- if not .Values.persistence.objectStorage.workloadIdentity.enabled }}
GCS_CREDENTIALS_JSON: {{ include "sam.gcs.credentialsJson" . | b64enc }}
{{- end }}
GCS_BUCKET_NAME: {{ include "sam.gcs.bucketName" . | b64enc }}
{{- else }}
S3_ENDPOINT_URL: {{ include "sam.s3.url" . | b64enc }}
S3_BUCKET_NAME: {{ include "sam.s3.bucketName" . | b64enc }}
{{- if not .Values.persistence.objectStorage.workloadIdentity.enabled }}
AWS_ACCESS_KEY_ID: {{ include "sam.s3.accessKey" . | b64enc }}
AWS_SECRET_ACCESS_KEY: {{ include "sam.s3.secretKey" . | b64enc }}
{{- end }}
AWS_REGION: {{ .Values.persistence.s3.region | default "us-east-1" | b64enc }}
{{- end }}
{{- end }}