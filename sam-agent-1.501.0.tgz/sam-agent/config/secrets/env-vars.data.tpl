# Solace Broker Configuration
SOLACE_BROKER_URL: {{ .Values.solaceBroker.url | b64enc | quote }}
SOLACE_BROKER_USERNAME: {{ .Values.solaceBroker.username | b64enc | quote }}
SOLACE_BROKER_PASSWORD: {{ .Values.solaceBroker.password | b64enc | quote }}
SOLACE_BROKER_VPN: {{ .Values.solaceBroker.vpn | b64enc | quote }}
USE_TEMPORARY_QUEUES: {{ .Values.solaceBroker.useTemporaryQueues | toString | b64enc | quote }}

# SAM Namespace identifier (used for topic prefixes and scoping)
NAMESPACE: {{ required "global.persistence.namespaceId is required. Use a unique value per broker to prevent topic collisions." .Values.global.persistence.namespaceId | b64enc | quote }}

# LLM Service Configuration
LLM_SERVICE_GENERAL_MODEL_NAME: {{ .Values.llmService.generalModelName | b64enc | quote }}
LLM_SERVICE_ENDPOINT: {{ .Values.llmService.endpoint | b64enc | quote }}
LLM_SERVICE_API_KEY: {{ .Values.llmService.apiKey | b64enc | quote }}
SOLACE_DEV_MODE: {{ printf "False" | b64enc | quote }}

{{- range $key, $value := .Values.environmentVariables }}
{{ $key }}: {{ $value | toString | b64enc | quote }}
{{- end }}
